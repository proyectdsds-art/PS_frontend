---
name: INEGI Servicio Social Digital Guide
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#434750'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#747781'
  outline-variant: '#c4c6d2'
  surface-tint: '#3c5d9c'
  primary: '#001b44'
  on-primary: '#ffffff'
  primary-container: '#002f6c'
  on-primary-container: '#7999dc'
  inverse-primary: '#aec6ff'
  secondary: '#006a65'
  on-secondary: '#ffffff'
  secondary-container: '#80f2ea'
  on-secondary-container: '#006f6a'
  tertiary: '#001e39'
  on-tertiary: '#ffffff'
  tertiary-container: '#00335c'
  on-tertiary-container: '#6d9dd7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#aec6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#224583'
  secondary-fixed: '#83f5ed'
  secondary-fixed-dim: '#64d9d0'
  on-secondary-fixed: '#00201e'
  on-secondary-fixed-variant: '#00504c'
  tertiary-fixed: '#d2e4ff'
  tertiary-fixed-dim: '#a0c9ff'
  on-tertiary-fixed: '#001c37'
  on-tertiary-fixed-variant: '#07497d'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
typography:
  headline-xl:
    fontFamily: Public Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-xl-mobile:
    fontFamily: Public Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
  headline-lg:
    fontFamily: Public Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-lg-mobile:
    fontFamily: Public Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-md:
    fontFamily: Public Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Public Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Public Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Public Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Public Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Public Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Public Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes a modern, welcoming, and rigorously accessible digital experience for university students, interns, and academic coordinators navigating the Servicio Social and Estadía Profesional procedures at Mexico's National Institute of Statistics and Geography (INEGI). 

Rooted in a **Corporate / Modern Civic** visual movement, the system transforms traditionally intimidating, dense public administrative notices into clear, supportive, and structured digital flows. The design communicates institutional authority, data accuracy, and civic reliability while feeling approachable, youth-oriented, and friction-free.

Key stylistic tenets:
- **Clarity over ornament:** Uncluttered layouts, high contrast ratios, and deliberate content chunking reduce procedural cognitive load.
- **Supportive guidance:** Stepper hierarchies, clear checklist validations, status indicators, and contextual alert callouts guide students through submission deadlines and regulatory compliance.
- **Civic integrity:** A restrained palette of deep Mexican institutional blues paired with vibrant technical teal highlights precision and public service dignity.

## Colors

The color palette is engineered for institutional legitimacy, rigorous legibility, and effortless mobile scanning.

### Palette Architecture
- **Primary Navy (`#002F6C`):** The institutional anchor representing INEGI's authority and stability. Used for primary buttons, global navigation bars, top app bars, and high-impact headlines.
- **Tertiary Executive Blue (`#0F4C81`):** A mid-tone deep blue providing visual relief for secondary headers, selected states, and navigational tabs.
- **Secondary Teal (`#009A93`):** An energetic, modern civic accent used for active stepper nodes, interactive indicators, inline hyperlinks, progress bars, and positive affirmation tags.
- **Slate Text Neutral (`#1E293B`):** Deep charcoal slate replacing stark `#000000` to prevent eye strain across long legal texts while guaranteeing WCAG AAA contrast against light backgrounds.
- **Canvas & Surface Neutral (`#F8FAFC` & `#FFFFFF`):** Crisp, clinical, and clean surfaces that provide structured containment for cards, checklists, and legal acknowledgement boxes.

### Functional Roles
- **Surface & Backgrounds:** Background canvas uses `#F8FAFC`, card containers use `#FFFFFF`, and muted structural borders utilize `#E2E8F0`.
- **States & Signals:**
  - *Success / Ready:* `#0D9488` (Teal Dark)
  - *Warning / Important Action:* `#D97706` (Warm Amber for immediate document deadlines)
  - *Info / Required Notification:* `#0284C7` (Sky Blue)
  - *Critical / Error:* `#DC2626` (Red)

## Typography

This design system uses **Public Sans** across all roles. Designed specifically for government interfaces and public services, Public Sans provides optimal rendering on lower-cost mobile screens, crystal-clear distinction between numerals and capital letters, and uncompromised neutrality.

Hierarchy guidelines:
- **Headlines:** Displayed in 600 or 700 weight with tight tracking (`-0.015em`) for clear sectional prominence.
- **Body:** Set with generous line heights (`1.5x`) to ensure dense legal regulations, institutional notices, and requirements remain legible on compact displays.
- **Acknowledgement & Legal Text:** Retains standard body sizing (`14px`) rather than fine print, honoring transparency and informed consent.

## Layout & Spacing

The layout is built upon an 8pt rhythmic grid optimized for mobile ergonomics and one-handed thumb interaction.

- **Mobile Viewport (up to 640px):** Single-column fluid stacked layout with a fixed screen boundary margin of `1rem` (16px) and interior element spacing using `space-md` (16px).
- **Tablet & Split-view (641px - 1024px):** Dual-column layout allocating 40% width to step navigation/document tracking and 60% to context checklists and form inputs, with `gutter-tablet` set to `1.5rem` (24px).
- **Component Breathing Room:** Grouped form fields and checklist rows maintain `space-sm` (8px) internal gaps, while independent card modules maintain `space-md` (16px) to `space-lg` (24px) vertical separation.

## Elevation & Depth

To avoid visual fatigue while maintaining tactile separation between process steps, this system prioritizes **tonal layering and low-contrast borders** over heavy drop shadows.

- **Level 0 (Flat Ground):** `#F8FAFC` base application background.
- **Level 1 (Card & Module Layer):** Pure `#FFFFFF` surface accompanied by a crisp 1px border in `#E2E8F0` and an ultra-subtle ambient shadow: `0 1px 3px rgba(15, 23, 42, 0.05)`.
- **Level 2 (Active Document Cards & Sticky Navigation):** `#FFFFFF` surface, 1px border in `#CBD5E1`, with shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.07), 0 2px 4px -2px rgba(15, 23, 42, 0.05)`.
- **Level 3 (Modal Bottom Sheets & Urgent Banners):** Elevated with shadow: `0 10px 15px -3px rgba(0, 47, 108, 0.08), 0 4px 6px -4px rgba(0, 47, 108, 0.04)`.

## Shapes

The design system adopts a balanced **Rounded (`2`)** curvature profile (`0.5rem` / 8px default radius).

- **Buttons & Form Fields:** 8px (`0.5rem`) radius for clear, clickable affordance without feeling toy-like.
- **Cards, Panels, and Callouts:** 12px to 16px (`rounded-lg` to `rounded-xl`) to neatly containerize complex checklists and instructions.
- **Status Badges & Chips:** Semi-pill or 6px rounded geometry to differentiate metadata tags from interactive form elements.

## Components

### Buttons
- **Primary:** Background `#002F6C`, text `#FFFFFF`, 8px border radius, 48px minimum touch target. Active state deepens to `#001F47`.
- **Secondary / Action Accent:** Background `#009A93`, text `#FFFFFF`. Used for "Subir Archivo", "Confirmar Declaración", or "Enviar Trámite".
- **Outline / Secondary:** Border 1.5px solid `#002F6C`, transparent background, text `#002F6C`.
- **Ghost:** Text `#0F4C81`, no border, padded for accessible tapping.

### Step-by-Step Progress Tracker
- Horizontal progress bar connecting numbered circular nodes.
- Completed steps display a `#009A93` fill with a white checkmark icon.
- Active step features a `#002F6C` ring with bold white number and an outer focus halo.
- Incomplete steps display `#E2E8F0` fill with `#64748B` text.

### Document Checklist Cards
- Dedicated cards for required items: **CURP**, **NSS del IMSS**, **Fotografía reciente**, and **Carta de Presentación**.
- Each item contains:
  - Document title and format requirement pill (`PDF`, `Máx 5MB`).
  - Contextual status icon: Pending (dashed outline), Uploaded (teal check), or Conditionally Deferred (blue calendar icon for Carta de Presentación).
  - Quick action CTA ("Subir" or "Ver documento").

### Legal Acknowledgement Box (Aviso y Reglamento)
- Institutional framed card featuring a subtle 2px solid border in `#0F4C81`.
- Clean top label: *"Yo, [Nombre Completo]"* highlighted with an editable inline field or auto-populated credential token.
- Unabridged statement of compliance for the *Reglamento para Personas Prestadoras de Servicio* and *Aviso de Privacidad Simplificado*.
- High-contrast checkbox affirming understanding and direct acceptance.

### Urgent Callout Banners
- Used for strict submission deadlines (*"a más tardar al día siguiente"*).
- Light amber or teal tint background (`#FEF3C7` or `#F0FDFA`) with a solid 4px left accent bar and high-contrast icons.

### Help & Extension Directory Component
- Compact footer card grouping phone support (`449 970 5300`) alongside interactive quick-dial chips for specific internal extensions (`312783`, `312853`, `315652`).